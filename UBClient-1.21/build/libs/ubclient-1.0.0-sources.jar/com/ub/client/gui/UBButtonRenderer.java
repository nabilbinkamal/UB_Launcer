package com.ub.client.gui;

import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;

public final class UBButtonRenderer {
    private UBButtonRenderer() {
    }

    public static void render(class_332 context, class_4185 button, class_327 font) {
        String label = button.method_25369().getString();
        int color = buttonColor(label);
        if (button.method_49606()) color = lighten(color, 34);
        int x = button.method_46426();
        int y = button.method_46427();
        int right = x + button.method_25368();
        int bottom = y + button.method_25364();
        context.method_25294(x - 1, y - 1, right + 1, bottom + 1, 0xAA02080F);
        context.method_25294(x, y, right, bottom, 0xF20A1C2A);
        context.method_25294(x, y, right, y + 2, color | 0xFF000000);
        context.method_25294(x, bottom - 2, right, bottom, color | 0xFF000000);
        context.method_25294(x, y + 2, x + 2, bottom - 2, color | 0xFF000000);
        context.method_25294(right - 2, y + 2, right, bottom - 2, color | 0xFF000000);
        int textColor = button.method_49606() ? 0xFFFFFFFF : 0xFFE7F7FF;
        int textX = x + (button.method_25368() - font.method_27525(button.method_25369())) / 2;
        int textY = y + (button.method_25364() - 8) / 2;
        context.method_51439(font, button.method_25369(), textX, textY, textColor, true);
    }

    private static int buttonColor(String label) {
        String value = label.toLowerCase(java.util.Locale.ROOT);
        if (value.contains("single")) return 0xFF35C6F4;
        if (value.contains("multi")) return 0xFF3D82FF;
        if (value.contains("realm")) return 0xFF9A6CFF;
        if (value.contains("mod")) return 0xFFE36BFF;
        if (value.contains("option")) return 0xFF4DD9C0;
        if (value.contains("quit")) return 0xFFFF647C;
        if (value.contains("save") || value.contains("back")) return 0xFF35C6F4;
        if (value.contains("performance")) return 0xFFFFB84D;
        if (value.contains("keystroke")) return 0xFFC77DFF;
        if (value.contains("hud")) return 0xFF45E0B5;
        if (value.contains("custom")) return 0xFF5EA7FF;
        return 0xFF8BD8FF;
    }

    private static int lighten(int color, int amount) {
        int red = Math.min(255, ((color >> 16) & 255) + amount);
        int green = Math.min(255, ((color >> 8) & 255) + amount);
        int blue = Math.min(255, (color & 255) + amount);
        return (red << 16) | (green << 8) | blue;
    }
}
