package com.ub.client.gui;

import com.ub.client.UB21Settings;
import com.ub.client.mixin.TitleScreenAccessor;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class UBMenuScreen extends class_437 {
    private final class_437 parent;
    private int left;
    private int top;

    public UBMenuScreen(class_437 parent) {
        super(class_2561.method_43470("UB Client Menu"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        left = field_22789 / 2 - 115;
        top = field_22790 / 2 - 70;
        method_37063(toggle("Custom UI", () -> UB21Settings.customUi, value -> UB21Settings.customUi = value, 0));
        method_37063(toggle("Modern HUD", () -> UB21Settings.modernHud, value -> UB21Settings.modernHud = value, 1));
        method_37063(toggle("Keystrokes", () -> UB21Settings.keystrokes, value -> UB21Settings.keystrokes = value, 2));
        method_37063(toggle("Performance Mode", () -> UB21Settings.performanceMode, value -> UB21Settings.performanceMode = value, 3));
        method_37063(class_4185.method_46430(class_2561.method_43470("Save & Back"), button -> {
            UB21Settings.save();
            if (field_22787 != null) field_22787.method_1507(parent);
        }).method_46434(left, top + 128, 230, 20).method_46431());
    }

    private class_4185 toggle(String name, java.util.function.BooleanSupplier getter,
                                java.util.function.Consumer<Boolean> setter, int row) {
        return class_4185.method_46430(class_2561.method_43470(label(name, getter.getAsBoolean())), button -> {
            setter.accept(!getter.getAsBoolean());
            button.method_25355(class_2561.method_43470(label(name, getter.getAsBoolean())));
        }).method_46434(left, top + row * 27, 230, 20).method_46431();
    }

    private static String label(String name, boolean enabled) {
        return name + ": " + (enabled ? "ON" : "OFF");
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Do not call Screen.renderBackground here: shader/UI mods may already
        // blur the frame and Minecraft allows only one blur pass per frame.
        context.method_25294(0, 0, field_22789, field_22790, 0xE607121D);
        context.method_25294(left - 18, top - 30, left + 248, top + 168, 0xE6091B2A);
        context.method_25294(left - 18, top - 30, left + 248, top - 28, 0xFF65C7FF);
        context.method_51433(field_22793, "PERSONALIZE YOUR CLIENT", left - 2, top - 47, 0xFF79BFE0, true);
        context.method_51433(field_22793, "Toggle features safely at any time", left - 2, top - 34, 0xFF7098AA, false);
        int titleWidth = field_22793.method_27525(field_22785);
        context.method_51439(field_22793, field_22785, field_22789 / 2 - titleWidth / 2, top - 19, 0xFFB9E9FF, true);
        super.method_25394(context, mouseX, mouseY, delta);
        for (class_4068 renderable : ((TitleScreenAccessor) (Object) this).ubclient$getRenderables()) {
            if (renderable instanceof class_4185 button) UBButtonRenderer.render(context, button, field_22793);
        }
    }

    public boolean shouldPause() {
        return false;
    }
}
