package com.ub.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.gen.Accessor;
import java.util.List;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;

@Mixin(class_437.class)
public interface TitleScreenAccessor {
    @Invoker("addRenderableWidget")
    <T extends class_364 & class_4068 & class_6379> T ubclient$addRenderableWidget(T widget);

    @Accessor("renderables")
    List<class_4068> ubclient$getRenderables();
}
