package com.ub.client.mixin;

import com.ub.client.UB21Settings;
import com.ub.client.gui.UBMenuScreen;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_442;
import com.ub.client.gui.UBButtonRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public final class TitleScreenMixin {
    @Inject(method = "init", at = @At("TAIL"))
    private void ubclient$addMenuButton(CallbackInfo callbackInfo) {
        class_442 screen = (class_442) (Object) this;
        for (class_4068 renderable : ((TitleScreenAccessor) screen).ubclient$getRenderables()) {
            if (renderable instanceof class_4185 button) positionMinecraftButton(button, screen.field_22789, screen.field_22790);
        }
        ((TitleScreenAccessor) screen).ubclient$addRenderableWidget(class_4185.method_46430(class_2561.method_43470("UB MENU"), button ->
                class_310.method_1551().method_1507(new UBMenuScreen(screen)))
            .method_46434(10, 10, 90, 20)
            .method_46431());
    }

    private static void positionMinecraftButton(class_4185 button, int width, int height) {
        String label = button.method_25369().getString().toLowerCase(java.util.Locale.ROOT);
        int center = width / 2;
        int y = Math.max(150, height / 2 - 90);
        if (label.contains("single")) button.method_48229(center - 112, y);
        else if (label.contains("multi")) button.method_48229(center - 112, y + 34);
        else if (label.contains("realm")) button.method_48229(center - 112, y + 68);
        else if (label.equals("mods")) button.method_48229(center + 5, y + 68);
        else if (label.contains("option")) button.method_48229(center - 112, y + 108);
        else if (label.contains("quit")) button.method_48229(center + 5, y + 108);
        else if (label.contains("language") || label.contains("accessibility")) button.method_48229(-100, -100);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void ubclient$renderBranding(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo callbackInfo) {
        if (!UB21Settings.customUi) return;
        class_442 screen = (class_442) (Object) this;
        int width = screen.field_22789;
        int center = width / 2;
        // Full-screen dark veil keeps the selected background while giving the
        // screen the compact launcher composition shown in the reference.
        context.method_25294(0, 0, width, screen.field_22790, 0x72030810);
        context.method_25294(0, 0, width, 62, 0xE607121D);
        context.method_25294(0, 60, width, 63, 0xFF65C7FF);
        var font = class_310.method_1551().field_1772;
        context.method_51433(font, "UB CLIENT", 22, 18, 0xFFB9E9FF, true);
        context.method_51433(font, "MODERN EDITION  |  1.21+", 22, 36, 0xFFA9DFFF, true);
        context.method_51433(font, "CUSTOM UI", width - 78, 18, 0xFF65C7FF, true);
        context.method_51433(font, "READY", width - 48, 36, 0xFF55E0B6, true);
        context.method_51433(font, "UB CLIENT", center - font.method_1727("UB CLIENT") / 2, 108, 0xFFE5F8FF, true);
        context.method_51433(font, "CHOOSE YOUR EXPERIENCE", center - font.method_1727("CHOOSE YOUR EXPERIENCE") / 2, 124, 0xFF79BFE0, false);
        for (class_4068 renderable : ((TitleScreenAccessor) (Object) this).ubclient$getRenderables()) {
            if (renderable instanceof class_4185 button) UBButtonRenderer.render(context, button, font);
        }
    }
}
