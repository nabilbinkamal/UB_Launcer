package com.ub.client.gui;

import I;
import com.ub.client.UBClientSettings;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class UBSettingsScreen extends class_437 {
    private final class_437 parent;
    private int left;
    private int top;

    public UBSettingsScreen(class_437 parent) {
        super(class_2561.method_43470("UB Client Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        left = this.field_22789 / 2 - 115;
        top = this.field_22790 / 2 - 92;
        method_37063(toggleButton("HUD", () -> UBClientSettings.hudEnabled,
                value -> UBClientSettings.hudEnabled = value, 0));
        method_37063(toggleButton("Keystrokes", () -> UBClientSettings.keystrokesEnabled,
                value -> UBClientSettings.keystrokesEnabled = value, 1));
        method_37063(toggleButton("Coordinates", () -> UBClientSettings.coordinatesEnabled,
                value -> UBClientSettings.coordinatesEnabled = value, 2));
        method_37063(toggleButton("Zoom (C)", () -> UBClientSettings.zoomEnabled,
                value -> UBClientSettings.zoomEnabled = value, 3));
        method_37063(toggleButton("Toggle Sprint (R)", () -> UBClientSettings.toggleSprintEnabled,
                value -> UBClientSettings.toggleSprintEnabled = value, 4));
        method_37063(toggleButton("Fullbright (G)", () -> UBClientSettings.fullbrightEnabled,
                value -> UBClientSettings.fullbrightEnabled = value, 5));
        method_37063(class_4185.method_46430(class_2561.method_43470("Save & Back"), button -> {
            UBClientSettings.save();
            if (field_22787 != null) field_22787.method_1507(parent);
        }).method_46434(left, top + 178, 230, 20).method_46431());
    }

    private class_4185 toggleButton(String name, java.util.function.BooleanSupplier getter,
                                      java.util.function.Consumer<Boolean> setter, int row) {
        var button = class_4185.method_46430(class_2561.method_43470(label(name, getter.getAsBoolean())), ignored -> {
            setter.accept(!getter.getAsBoolean());
            ignored.method_25355(class_2561.method_43470(label(name, getter.getAsBoolean())));
        }).method_46434(left, top + row * 28, 230, 20).method_46431();
        return button;
    }

    private static String label(String name, boolean enabled) {
        return name + ": " + (enabled ? "ON" : "OFF");
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        context.method_25294(left - 18, top - 28, left + 248, top + 218, 0xE6091B2A);
        context.method_25294(left - 18, top - 28, left + 248, top - 26, 0xFF65C7FF);
        var titleWidth = field_22793.method_27525(field_22785);
        context.method_27535(field_22793, field_22785, field_22789 / 2 - titleWidth / 2, top - 18, 0xFFB9E9FF);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
