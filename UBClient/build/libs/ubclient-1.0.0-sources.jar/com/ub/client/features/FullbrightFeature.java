package com.ub.client.features;

import com.ub.client.UBClientSettings;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class FullbrightFeature {
    public static class_304 fullbrightKey;
    public static boolean isFullbright = false;

    public static void register() {
        fullbrightKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.ubclient.fullbright", 
                class_3675.class_307.field_1668, 
                GLFW.GLFW_KEY_G, 
                "category.ubclient.features"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!UBClientSettings.fullbrightEnabled) {
                isFullbright = false;
                return;
            }
            while (fullbrightKey.method_1436()) {
                isFullbright = !isFullbright;
                
                // Force a lightmap update so the screen brightens instantly
                if (client.field_1769 != null) {
                    client.field_1769.method_3279();
                }
            }
        });
    }
}
