package com.ub.client.features;

import com.ub.client.UBClientSettings;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class ToggleSprintFeature {
    public static class_304 toggleSprintKey;
    public static boolean isSprintToggled = false;

    public static void register() {
        toggleSprintKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.ubclient.togglesprint", 
                class_3675.class_307.field_1668, 
                GLFW.GLFW_KEY_R, 
                "category.ubclient.features"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!UBClientSettings.toggleSprintEnabled) {
                isSprintToggled = false;
                return;
            }
            while (toggleSprintKey.method_1436()) {
                isSprintToggled = !isSprintToggled;
            }

            if (isSprintToggled && client.field_1724 != null) {
                if (client.field_1690.field_1894.method_1434() && !client.field_1724.method_5715() && !client.field_1724.field_5976) {
                    client.field_1724.method_5728(true);
                }
            }
        });
    }
}
