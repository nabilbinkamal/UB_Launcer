package com.ub.client.features;

import com.ub.client.UBClientSettings;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class ZoomFeature {
    public static class_304 zoomKey;
    public static boolean isZooming = false;
    public static double currentZoom = 1.0;

    public static void register() {
        zoomKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.ubclient.zoom", 
                class_3675.class_307.field_1668, 
                GLFW.GLFW_KEY_C, 
                "category.ubclient.features"
        ));
    }

    public static boolean isZoomPressed() {
        if (!UBClientSettings.zoomEnabled) {
            isZooming = false;
            currentZoom = 1.0;
            return false;
        }
        if (zoomKey != null) {
            isZooming = zoomKey.method_1434();
            return isZooming;
        }
        return false;
    }

    public static double manageZoom(double fov) {
        if (isZoomPressed()) {
            currentZoom = Math.max(0.2, currentZoom - 0.05);
        } else {
            currentZoom = Math.min(1.0, currentZoom + 0.05);
        }
        return fov * currentZoom;
    }
}
