package com.ub.client.hud;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_332;
import com.ub.client.UBClientSettings;

public class UBHudOverlay implements HudRenderCallback {
    @Override
    public void onHudRender(class_332 drawContext, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (client.field_1690.field_1842 || !UBClientSettings.hudEnabled) {
            return;
        }

        int x = 10;
        int y = 10;
        int panelWidth = 132;
        int panelHeight = client.field_1724 == null ? 42 : 58;

        // Modern light-blue UB Client panel.
        drawContext.method_25294(x - 6, y - 6, x + panelWidth, y + panelHeight, 0xCC071521);
        drawContext.method_25294(x - 6, y - 6, x + panelWidth, y - 4, 0xFF65C7FF);
        drawContext.method_25303(client.field_1772, "UB CLIENT", x, y, 0xFFB9E9FF);

        int fps = client.method_47599();
        drawContext.method_25303(client.field_1772, "FPS  " + fps, x, y + 12, 0xFFE8F8FF);
        
        // Draw Coordinates if in game
        if (client.field_1724 != null && UBClientSettings.coordinatesEnabled) {
            int blockX = client.field_1724.method_31477();
            int blockY = client.field_1724.method_31478();
            int blockZ = client.field_1724.method_31479();
            drawContext.method_25303(client.field_1772, String.format("XYZ  %d  %d  %d", blockX, blockY, blockZ), x, y + 24, 0xFFA9DFFF);
        }

        // Draw Feature Status
        int statusY = y + 38;
        if (com.ub.client.features.ToggleSprintFeature.isSprintToggled) {
            drawContext.method_25303(client.field_1772, "SPRINT  ON", x, statusY, 0xFF72D5FF);
            statusY += 12;
        }
        if (com.ub.client.features.FullbrightFeature.isFullbright) {
            drawContext.method_25303(client.field_1772, "FULLBRIGHT  ON", x, statusY, 0xFFBDEBFF);
        }

        // Draw Keystrokes
        if (UBClientSettings.keystrokesEnabled) drawKeystrokes(drawContext, client);
    }

    private void drawKeystrokes(class_332 drawContext, class_310 client) {
        int width = client.method_22683().method_4486();
        int height = client.method_22683().method_4502();
        
        int startX = width - 86;
        int startY = height - 88;

        // W
        drawKey(drawContext, client, client.field_1690.field_1894, startX + 22, startY, 20, 20, "W");
        // A
        drawKey(drawContext, client, client.field_1690.field_1913, startX, startY + 22, 20, 20, "A");
        // S
        drawKey(drawContext, client, client.field_1690.field_1881, startX + 22, startY + 22, 20, 20, "S");
        // D
        drawKey(drawContext, client, client.field_1690.field_1849, startX + 44, startY + 22, 20, 20, "D");
        // Space
        drawKey(drawContext, client, client.field_1690.field_1903, startX, startY + 44, 64, 16, "SPACE");
    }

    private void drawKey(class_332 context, class_310 client, net.minecraft.class_304 key, int x, int y, int w, int h, String label) {
        boolean pressed = key.method_1434();
        int bgColor = pressed ? 0xFF55B9EA : 0xCC0B2030;
        int borderColor = pressed ? 0xFFB9EEFF : 0xFF397B9D;
        int textColor = pressed ? 0xFF04131D : 0xFFE5F8FF;
        
        context.method_25294(x, y, x + w, y + h, bgColor);
        context.method_25294(x, y, x + w, y + 1, borderColor);
        context.method_25294(x, y + h - 1, x + w, y + h, borderColor);
        
        int textWidth = client.field_1772.method_1727(label);
        int textX = x + (w - textWidth) / 2;
        int textY = y + (h - client.field_1772.field_2000) / 2 + 1;
        context.method_51433(client.field_1772, label, textX, textY, textColor, false);
    }
}
