package com.ub.client.mixin;

import net.minecraft.class_332;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public class TitleScreenMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        class_442 screen = (class_442) (Object) this;
        int width = screen.field_22789;
        
        // Draw a sleek dark header to cover the vanilla logo
        context.method_25294(0, 0, width, 80, 0xDD05090C); // Very dark, mostly opaque
        context.method_25294(0, 80, width, 82, 0xFF68DDA8); // Cyan/Green border strip
        
        // Draw UB Client Custom Logo Text
        context.method_51448().method_22903();
        context.method_51448().method_22905(3.0f, 3.0f, 3.0f);
        int textWidth = net.minecraft.class_310.method_1551().field_1772.method_1727("UB Client");
        context.method_25303(
                net.minecraft.class_310.method_1551().field_1772, 
                "UB Client", 
                (int)((width / 2f) / 3.0f) - (textWidth / 2), 
                8, 
                0x68DDA8
        );
        context.method_51448().method_22909();

        // Draw Subtitle
        int subTextWidth = net.minecraft.class_310.method_1551().field_1772.method_1727("Premium Edition");
        context.method_25303(
                net.minecraft.class_310.method_1551().field_1772, 
                "Premium Edition", 
                (width / 2) - (subTextWidth / 2), 
                60, 
                0x82C7FF
        );
    }
}
